/* Q1: Find how much amount spent by each customer on artists? 
Write a query to return customer name, artist name and total spent */


select concat(c.first_name, ' ' , c.last_name) as customer_name,
a.name as artist_name, sum(il.unit_price*il.quantity) as total_spent
from customer c
join invoice i on c.customer_id = i.customer_id
join invoice_line il on i.invoice_id = il.invoice_id
join track t on il.track_id = t.track_id
join album al on t.album_id = al.album_id
join artist a on al.artist_id = a.artist_id
group by customer_name, artist_name
order by total_spent desc;
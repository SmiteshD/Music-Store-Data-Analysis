/* Q2: We want to find out the most popular music Genre for each country. We determine the most popular genre as the genre 
with the highest amount of purchases. Write a query that returns each country along with the top Genre. For countries where 
the maximum number of purchases is shared return all Genres. */

select c.country,
case when count(distinct g.name) > 1
then group_concat(distinct g.name order by g.name separator ', ')
else max(g.name)
end as top_genre
from customer c
join invoice i on c.customer_id = i.customer_id
join invoice_line il on i.invoice_id = il.invoice_id
join track t on il.track_id = t.track_id
join genre g on t.genre_id = g.genre_id
group by c.country
having count(distinct i.invoice_id) = (
select count(distinct i2.invoice_id)
from customer c2
join invoice i2 on c2.customer_id = i2.customer_id
where c2.country = c.country
group by c2.country
order by count(distinct i2.invoice_id) desc
limit 1);

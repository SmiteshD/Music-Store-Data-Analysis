--  Who is the senior most employee based on job title?

select concat(first_name," ",last_name) as Senior_Most_Employee
from employee
where hire_date = (select min(hire_date) from employee);



select title, concat(first_name," ",last_name) as Senior_Most_Employee
from employee
order by levels desc
limit 1;
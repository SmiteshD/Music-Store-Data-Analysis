/* Q5: Who is the best customer? The customer who has spent the most money will be declared the best customer. 
Write a query that returns the person who has spent the most money.*/


select customer.customer_id, concat(first_name," ",last_name) as customer_name, sum(total) as total_spending
from customer
join invoice on customer.customer_id = invoice.customer_id
group by customer.customer_id, customer_name
order by total_spending desc
limit 1;
-- Which countries have the most Invoices?

select billing_country, count(*) as no_of_invoices 
from invoice
group by billing_country
order by count(*) desc
/* Q2: Let's invite the artists who have written the most rock music in our dataset. 
Write a query that returns the Artist name and total track count of the top 10 rock bands. */

select artist.name as artist_name, 
count(track.track_id) as Track_Count,genre.name
from track
join album ON track.album_id = album.album_id
join artist ON album.artist_id = artist.artist_id
join genre ON track.genre_id = genre.genre_id
where genre.name = 'Rock'
group by artist.name
order by Track_Count desc
limit 10